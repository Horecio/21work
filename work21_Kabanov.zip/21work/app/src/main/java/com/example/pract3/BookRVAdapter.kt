package com.example.pract3

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

    class BookRVAdapter(context: Context?, val data: MutableList<Book>): RecyclerView.Adapter<BookRVAdapter.BookViewHolder?>() {
        private val layoutInflater: LayoutInflater = android.view.LayoutInflater.from(context)

        private var iClickListener: ItemClickListener? = null

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
            val view: View = layoutInflater.inflate(R.layout.list_book, parent, false)
            return BookViewHolder(view)
        }

        override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
            val item = data[position]
            holder.titleTextView.text = item.title
            holder.authorTextView.text = item.author
        }

        override fun getItemCount(): Int = data.size

        fun setClickListener(itemClickListener: ItemClickListener?){
            iClickListener = itemClickListener
        }
        inner class BookViewHolder(item: View): RecyclerView.ViewHolder(item), View.OnClickListener {
            var titleTextView: TextView = item.findViewById(R.id.tvName)
            var authorTextView: TextView = item.findViewById(R.id.tvEmail)

            init {
                itemView.setOnClickListener(this)
            }

            override fun onClick(view: View?) {
                iClickListener?.onItemClick(view, adapterPosition)


            }
        }
        interface ItemClickListener{
            fun onItemClick(view: View?, position: Int)
        }

    }
