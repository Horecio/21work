package com.example.pract3

data class Book(
    var title:String,
    var author:String
) {}